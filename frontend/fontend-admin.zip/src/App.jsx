import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import Home from './components/Home'
import Layout from './components/Layout'
import AddTestimonial from './components/AddTestimonial'

function App() {
  let router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          path: '',
          element: <Home />,
        },
        {
          path: '/add-testimonial',
          element: <AddTestimonial />,
        }
      ]
    }
  ])

  return (
    <>
      <RouterProvider router={router} />

    </>
  )
}

export default App
